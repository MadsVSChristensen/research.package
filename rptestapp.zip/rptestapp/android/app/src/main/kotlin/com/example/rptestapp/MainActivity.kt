package com.example.rptestapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
